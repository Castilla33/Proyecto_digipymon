class Enemigo:
    def __init__(self,nombre):
        self.nombre = nombre
        self.lista_digipymon = []
        self.cantidad_digipymon = 0
    def añadir_digipymon(self,digipymon):
        self.lista_digipymon.append(digipymon)
        self.cantidad_digipymon += 1

enemigo = Enemigo("Javi")
print(enemigo)
        